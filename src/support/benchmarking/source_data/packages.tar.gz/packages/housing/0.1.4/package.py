# -*- coding: utf-8 -*-

name = 'housing'

version = '0.1.4'

requires = [
    'ascent-2.6+<3',
    'heroine-2.5+<3',
    'blackberry-0.7'
]

timestamp = 1599561649

format_version = 2
