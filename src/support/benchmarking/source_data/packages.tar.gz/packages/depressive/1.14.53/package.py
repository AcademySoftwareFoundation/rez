# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.14.53'

requires = [
    'disconnection-2',
    'fool-2014+<2017',
    'cart-0',
    'lecture-2.19+<3',
    'fig-1',
    'attribute-1',
    'elephant-1',
    'pecan-1',
    'ram-4',
    'authorization-3',
    'scrambled-0.4+<1',
    'special-0',
    'robot-0'
]

timestamp = 1600130613

format_version = 2
