# -*- coding: utf-8 -*-

name = 'depressive'

version = '0.1.0'

requires = [
    'fool-2014+<2016',
    'cart-0',
    'cinema-0',
    '~ravioli-2+<3',
    '!vivo',
    '!derivative'
]

timestamp = 1600130103

format_version = 2
