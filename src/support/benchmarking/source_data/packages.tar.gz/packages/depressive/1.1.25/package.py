# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.1.25'

requires = [
    'fool-2014+<2016',
    'cart-0'
]

timestamp = 1600130118

format_version = 2
