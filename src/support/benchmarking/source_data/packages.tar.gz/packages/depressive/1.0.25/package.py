# -*- coding: utf-8 -*-

name = 'depressive'

version = '1.0.25'

requires = [
    'fool-2014+<2016',
    'cart-0'
]

timestamp = 1600130563

format_version = 2
