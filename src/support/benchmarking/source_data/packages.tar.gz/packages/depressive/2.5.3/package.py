# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.5.3'

requires = [
    'ram-4+<6',
    'authorization-3',
    'impala-0',
    'disconnection-2',
    'fool-2014+<2018',
    'weapon-2.49+<3',
    'harmony-1',
    'fig-1',
    'profit-4',
    'detective-0',
    'elephant-1',
    'periodical-1',
    'special-0',
    'robot-0',
    'spawn-3.52+<4'
]

timestamp = 1600130700

format_version = 2
