# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.60.16'

requires = [
    'impala-0',
    'disconnection-2',
    'fool-2014+<2018',
    'weapon-2.49+<3',
    'service-1',
    'harmony-1',
    'fig-1',
    'authorization-3',
    'detective-0',
    'profit-4',
    'elephant-1',
    'periodical-1',
    'special-0',
    'robot-0',
    'spawn-3.52+<4'
]

timestamp = 1600130403

format_version = 2
