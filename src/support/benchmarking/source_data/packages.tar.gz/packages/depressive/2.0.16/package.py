# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.0.16'

requires = [
    'impala-0',
    'disconnection-2',
    'fool-2014+<2018',
    'cart-0',
    'lecture-2.19+<3',
    'fig-1',
    'attribute-1',
    'authorization-3',
    'elephant-1',
    'scrambled-0.4+<1',
    'special-0',
    'robot-0'
]

timestamp = 1600130189

format_version = 2
