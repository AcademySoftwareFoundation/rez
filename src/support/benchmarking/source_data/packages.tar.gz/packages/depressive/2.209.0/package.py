# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.209.0'

requires = [
    'pear-1.5+<2',
    'impala-0',
    'otter-1.27+<2',
    'disconnection-2.280+<4',
    'fool-2014+<2020',
    'kazoo-0+<1',
    'weapon-2.49+<3',
    'paper-0+<1',
    'student-0.6.2+<1',
    'peacoat-9',
    'service-1',
    'harmony-1+<3',
    'fig-1',
    'authorization-3',
    'detective-0',
    'profit-4',
    'elephant-1',
    'periodical-1',
    'special-0+<2',
    'robot-0',
    'armoire-3+<5'
]

timestamp = 1600130140

format_version = 2
