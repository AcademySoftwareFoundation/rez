# -*- coding: utf-8 -*-

name = 'depressive'

version = '2.4.98'

requires = [
    'impala-0',
    'disconnection-2',
    'fool-2014+<2018',
    'spawn-3.52+<4',
    'weapon-2.49+<3',
    'fig-1',
    'ram-4',
    'authorization-3',
    'profit-4',
    'detective-0',
    'elephant-1',
    'periodical-1',
    'scrambled-0.4+<1',
    'special-0',
    'robot-0'
]

timestamp = 1600130816

format_version = 2
