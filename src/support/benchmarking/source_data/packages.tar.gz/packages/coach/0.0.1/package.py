# -*- coding: utf-8 -*-

name = 'coach'

version = '0.0.1'

requires = [
    'mythology-0.0+<2.0',
    'ascent-2.7+<3',
    'waffle-0.10+<1',
    'heroine-2.14+<3',
    'litter-4'
]

timestamp = 1599562767

format_version = 2
