# -*- coding: utf-8 -*-

name = 'accountant'

version = '0.0.1'

requires = ['ascent-2.7+<3']

timestamp = 1599561772

format_version = 2
