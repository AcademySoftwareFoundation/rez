# -*- coding: utf-8 -*-

name = 'voyage'

version = '0.9.0'

requires = [
    'instrumentation-3.10+<6',
    'popcorn-0.24.1+<1',
    'millisecond-0.1.1+<1',
    'comics-41+',
    'solicitation-19+'
]

variants = [
    ['ascent-2.7'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561506

format_version = 2
