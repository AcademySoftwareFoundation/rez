# -*- coding: utf-8 -*-

name = 'catalogue'

version = '3.R2.4'

requires = [
    'bottom-3',
    'ascent-2'
]

timestamp = 1599561525

format_version = 2
