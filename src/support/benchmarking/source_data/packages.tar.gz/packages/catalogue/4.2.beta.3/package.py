# -*- coding: utf-8 -*-

name = 'catalogue'

version = '4.2.beta.3'

requires = [
    'bottom-4.1.1+<5',
    'ascent-2'
]

timestamp = 1599561524

format_version = 2
