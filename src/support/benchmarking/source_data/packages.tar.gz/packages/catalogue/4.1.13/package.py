# -*- coding: utf-8 -*-

name = 'catalogue'

version = '4.1.13'

requires = [
    'bottom-3.2v1+<4',
    'ascent-2'
]

timestamp = 1599561525

format_version = 2
