# -*- coding: utf-8 -*-

name = 'catalogue'

version = '4.2.beta.4.m1'

requires = [
    'bottom-4.1.1+<5',
    'ascent-2'
]

timestamp = 1599561525

format_version = 2
