# -*- coding: utf-8 -*-

name = 'catalogue'

version = '4.2.release.0.m1'

requires = [
    'bottom-4.1.2+<5',
    'ascent-2'
]

timestamp = 1599561525

format_version = 2
