# -*- coding: utf-8 -*-

name = 'toothpaste'

version = '3.0.2.0.m2'

requires = [
    'lawsuit-3+<4',
    'penguin-2.0.10.m0',
    'kendo-1.2.11',
    'biplane-1.6.37',
    'tractor-2.0.4',
    'devastation-4.1.0',
    'dividend-5.2.4'
]

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7']]

timestamp = 1599561555

format_version = 2
