# -*- coding: utf-8 -*-

name = 'toothpaste'

version = '2.8.12.0'

requires = [
    '~ascent-2.7.3+<3',
    '~dawn-CentOS-7'
]

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7']]

timestamp = 1599561555

format_version = 2
