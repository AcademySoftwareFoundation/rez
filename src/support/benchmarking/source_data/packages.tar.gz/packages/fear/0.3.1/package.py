# -*- coding: utf-8 -*-

name = 'fear'

version = '0.3.1'

requires = [
    'wheel-0.1.2+<1',
    '~bottom-3+<4.6'
]

timestamp = 1599561840

format_version = 2
