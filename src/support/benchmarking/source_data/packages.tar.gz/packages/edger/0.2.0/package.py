# -*- coding: utf-8 -*-

name = 'edger'

version = '0.2.0'

requires = [
    'ascent-2.7+<3',
    'waffle-0.6+<1',
    'spelt-1.22+<2',
    'belligerency-3',
    'drawer-2',
    'comfortable-1'
]

timestamp = 1599562001

format_version = 2
