# -*- coding: utf-8 -*-

name = 'muskrat'

version = '1.1.0'

variants = [
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7', 'ascent-2.7'],
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7', 'ascent-3.6']
]

timestamp = 1599561510

format_version = 2
