# -*- coding: utf-8 -*-

name = 'punch'

version = '2.0.2'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6']
]

timestamp = 1599561478

format_version = 2
