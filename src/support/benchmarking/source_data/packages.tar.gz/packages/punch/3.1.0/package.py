# -*- coding: utf-8 -*-

name = 'punch'

version = '3.1.0'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561478

format_version = 2
