# -*- coding: utf-8 -*-

name = 'apparel'

version = '1.2.1.m2'

requires = ['hermit-1.13+<2']

variants = [
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7', 'ascent-2.7'],
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7', 'ascent-3.6']
]

timestamp = 1599561540

format_version = 2
