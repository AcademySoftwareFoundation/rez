# -*- coding: utf-8 -*-

name = 'apparel'

version = '1.2.1.m0'

requires = ['hermit-1.12.1.m1+<1.13']

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-Ubuntu-12.04', 'ascent-2.7']]

timestamp = 1599561540

format_version = 2
