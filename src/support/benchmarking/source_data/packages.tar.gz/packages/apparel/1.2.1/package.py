# -*- coding: utf-8 -*-

name = 'apparel'

version = '1.2.1'

requires = [
    'ascent-2.7',
    'hermit-1.11.1'
]

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-Ubuntu-12.04']]

timestamp = 1599561540

format_version = 2
