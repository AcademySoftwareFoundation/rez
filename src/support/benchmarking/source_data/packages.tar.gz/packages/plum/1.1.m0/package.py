# -*- coding: utf-8 -*-

name = 'plum'

version = '1.1.m0'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6']
]

timestamp = 1599561578

format_version = 2
