# -*- coding: utf-8 -*-

name = 'plum'

version = '1.3.2'

requires = [
    'comics-41+',
    'solicitation-19+'
]

variants = [
    ['ascent-2.7'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561578

format_version = 2
