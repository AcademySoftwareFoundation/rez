# -*- coding: utf-8 -*-

name = 'ox'

version = '3.0.0'

requires = [
    '~romaine-0.8.1+<1',
    'haircut-4.0.2+<5',
    'baggy-0+<2',
    'dream-2',
    'operator-2',
    'potato-2.48.0+<3',
    'beret-0.19.1+<1',
    'instrumentation-3',
    'degradation-2',
    'waffle-0.37.1+<1',
    'lens-0',
    'act-4.12+<5',
    'publishing-1.84+<2',
    'knickers-0',
    '~processing-2015+<2019',
    '~bird-8+<12',
    '~jazz-0+<2',
    '~percentage-2.4+<5',
    '~spirit-3',
    '~founding-6.0.1+<7',
    'mythology-0+<2',
    'ascent-2.7',
    'councilor-1.6+<2'
]

timestamp = 1599561669

format_version = 2
