# -*- coding: utf-8 -*-

name = 'ox'

version = '2.3.2'

requires = [
    '~romaine-0+<1',
    '~haircut-3.24+<4',
    'minion-0',
    'baggy-0',
    'dream-0.33.4+<1.0',
    'operator-1.0.29+<2',
    'potato-2.48.0+<3',
    'beret-0.19.1+<1',
    'instrumentation-3',
    'degradation-2.0+<3',
    'waffle-0.14+<1',
    'lens-0',
    'act-2+<4',
    'publishing-1.84+<2',
    'knickers-0',
    '~processing-2015+<2018',
    '~bird-8+<11',
    '~jazz-0',
    '~accuracy-5+<9',
    '~percentage-2.4+<4',
    'mythology-0.4.1.m2+<1',
    'ascent-2.7'
]

timestamp = 1599561669

format_version = 2
