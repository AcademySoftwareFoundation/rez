# -*- coding: utf-8 -*-

name = 'ox'

version = '2.25.0'

requires = [
    '~romaine-0.8.1+<1',
    '~haircut-3.24+<4',
    'minion-0',
    'baggy-0+<2',
    'dream-0.33.4+<3',
    'operator-1.10+<2',
    'potato-2.48.0+<3',
    'beret-0.19.1+<1',
    'instrumentation-3',
    'degradation-2.0+<3',
    'waffle-0.14+<1',
    'lens-0',
    'act-4.12+<5',
    'publishing-1.84+<2',
    'knickers-0',
    '~processing-2015+<2019',
    '~bird-8+<12',
    '~jazz-0+<2',
    '~accuracy-5+<9',
    '~percentage-2.4+<5',
    'mythology-0+<2',
    'ascent-2.7',
    'councilor-1.6+<2'
]

timestamp = 1599561669

format_version = 2
