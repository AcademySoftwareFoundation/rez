# -*- coding: utf-8 -*-

name = 'slave'

version = '1.5.1'

requires = [
    'ascent-2.6+<3',
    'account-0.9+<1',
    'connotation-2+<3',
    'crazy-5+<6',
    'grandmother-0+<1',
    'heroine-2+<3',
    'cookbook-6+<7',
    'poverty-1.5.3+<2',
    'owl-1+<2',
    'porpoise-0+<1',
    'fatigues-1.2.1',
    'capitulation-19.7.1',
    'something-1+<2',
    'complex-2.12.2+<3',
    'patrolling-2.6+<3',
    'fiddle-1+<2',
    'good-2',
    'runway-3+<4',
    'inconvenience-0.8+<2',
    'tankful-0.9+<1',
    'hermit-1.10+<2',
    'belligerency-3+<4',
    'conversation-2',
    '~surrounds-4.8.3',
    'nourishment-0.6.1',
    'foundation-0.19.0',
    'goddess-0+<2',
    'usage-0.18.1',
    'finger-1.2+<2'
]

timestamp = 1599561946

format_version = 2
