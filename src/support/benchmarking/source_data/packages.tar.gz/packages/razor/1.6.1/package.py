# -*- coding: utf-8 -*-

name = 'razor'

version = '1.6.1'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561521

format_version = 2
