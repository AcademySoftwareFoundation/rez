# -*- coding: utf-8 -*-

name = 'razor'

version = '1.5'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6']
]

timestamp = 1599561521

format_version = 2
