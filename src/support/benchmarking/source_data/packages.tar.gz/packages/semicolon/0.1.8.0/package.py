# -*- coding: utf-8 -*-

name = 'semicolon'

version = '0.1.8.0'

requires = [
    'bird-7+<11',
    '~ascent-2.7+<3',
    'hugger-0.1.7+',
    'progression'
]

timestamp = 1599562752

format_version = 2
