# -*- coding: utf-8 -*-

name = 'bay'

version = '0.6.0'

requires = ['iceberg-0+<8']

variants = [
    ['ascent-2.7'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561573

format_version = 2
