# -*- coding: utf-8 -*-

name = 'grey'

version = '0.0.8'

requires = [
    'ascent-2.7+<3',
    'waffle',
    'heroine',
    'potato',
    'charm',
    'circadian'
]

timestamp = 1599561652

format_version = 2
