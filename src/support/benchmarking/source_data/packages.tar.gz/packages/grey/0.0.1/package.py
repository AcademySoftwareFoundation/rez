# -*- coding: utf-8 -*-

name = 'grey'

version = '0.0.1'

requires = [
    'ascent-2.7+<3',
    'waffle-0.10+<1',
    'heroine-2.14+<3',
    'potato-2.52.1',
    'charm-8.9.1',
    'circadian-1.7.8'
]

timestamp = 1599561652

format_version = 2
