# -*- coding: utf-8 -*-

name = 'diplomacy'

version = '0.70.1'

requires = [
    'ascent-2.7+<3',
    'shareholder-2.75+<3',
    'potato-2.46+<3',
    'waffle-0.15+<1',
    'spelt-1.26+<2',
    'liar-0.13+<1',
    'snow-2.3+<3',
    'drawer-2.5+<3',
    'instrumentation-3.11+<4',
    'mythology-0+<2'
]

timestamp = 1599561588

format_version = 2
