# -*- coding: utf-8 -*-

name = 'secretary'

version = '3.1.0'

requires = [
    'stitch-7',
    'endorsement-0',
    'barrier-2.7.0+<3',
    'waffle-0.16.1+<1',
    'battery-1.6.17+<1.8',
    'ascent-2.7+<4',
    'guilty-2',
    'hail-2.2+<3'
]

timestamp = 1599561786

format_version = 2
