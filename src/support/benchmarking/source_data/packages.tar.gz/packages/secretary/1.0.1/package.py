# -*- coding: utf-8 -*-

name = 'secretary'

version = '1.0.1'

requires = [
    'ascent-2.7+<3',
    'waffle-0.11.4+<1',
    'battery-1.6+<1.9',
    'quill-4.2+<5',
    'drizzle-1.3.3+<2',
    'clipper-2'
]

timestamp = 1599561786

format_version = 2
