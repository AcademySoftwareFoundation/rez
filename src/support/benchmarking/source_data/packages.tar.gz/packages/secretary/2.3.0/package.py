# -*- coding: utf-8 -*-

name = 'secretary'

version = '2.3.0'

requires = [
    'endorsement-0',
    'barrier-2+<3',
    'matrix-0.6.2',
    'clipper-2.0.0',
    'waffle-0.16.1+<1',
    'battery-1.6.17+<1.8',
    'ascent-2.7+<3',
    'guilty-2'
]

timestamp = 1599561786

format_version = 2
