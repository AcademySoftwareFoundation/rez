# -*- coding: utf-8 -*-

name = 'secretary'

version = '1.0.0'

requires = [
    'ascent-2.7+<3',
    'waffle-0.11.4',
    'gaffe-1.0.9.1',
    'quill-4.1b2',
    'drizzle-1.3.3',
    'clipper-2.0.0'
]

timestamp = 1599561786

format_version = 2
