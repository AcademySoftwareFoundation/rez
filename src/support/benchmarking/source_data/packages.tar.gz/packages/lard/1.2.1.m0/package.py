# -*- coding: utf-8 -*-

name = 'lard'

version = '1.2.1.m0'

requires = [
    'anarchist-1.10.0+<2',
    'proliferation-2.6.0+<3'
]

variants = [
    ['ascent-2.7'],
    ['ascent-3.6']
]

timestamp = 1599561472

format_version = 2
