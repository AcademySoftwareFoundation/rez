# -*- coding: utf-8 -*-

name = 'lard'

version = '3.0.2'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6']
]

timestamp = 1599561472

format_version = 2
