# -*- coding: utf-8 -*-

name = 'lard'

version = '7.0.0'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561472

format_version = 2
