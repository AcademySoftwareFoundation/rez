# -*- coding: utf-8 -*-

name = 'cappelletti'

version = '1.3.0'

requires = [
    'ascent-2.7+<3',
    'waffle-0.10+<1',
    'heroine-2.14+<3',
    'chauvinist-1.7.0+<2',
    'login-1.23.0+<2'
]

timestamp = 1599562021

format_version = 2
