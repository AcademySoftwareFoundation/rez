# -*- coding: utf-8 -*-

name = 'cappelletti'

version = '0.5.0'

requires = [
    'ascent-2.7+<3',
    'waffle-0.10+<1',
    'heroine-2.14+<3',
    'chauvinist-0.14.0+<1',
    'login-0.5.0+<1'
]

timestamp = 1599562021

format_version = 2
