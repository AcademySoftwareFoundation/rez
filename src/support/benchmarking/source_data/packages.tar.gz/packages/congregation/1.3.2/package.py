# -*- coding: utf-8 -*-

name = 'congregation'

version = '1.3.2'

requires = [
    'put-2.2.0.m3+<3',
    'lifetime-2.2.0.m2+<3'
]

variants = [
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7', 'ascent-2.7'],
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7', 'ascent-3.6']
]

timestamp = 1599561538

format_version = 2
