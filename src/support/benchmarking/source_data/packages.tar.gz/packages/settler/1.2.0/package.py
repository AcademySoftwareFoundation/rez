# -*- coding: utf-8 -*-

name = 'settler'

version = '1.2.0'

requires = [
    'ascent-2.7+<3',
    'caviar-0.8.2.m1+<19',
    'mythology-0.4+<2',
    'aside-2+<5',
    'collar-1.15+<2',
    'beetle-1.29+<4',
    'wad-0.2+<1'
]

timestamp = 1599561980

format_version = 2
