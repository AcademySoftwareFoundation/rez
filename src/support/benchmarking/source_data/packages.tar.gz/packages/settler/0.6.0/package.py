# -*- coding: utf-8 -*-

name = 'settler'

version = '0.6.0'

requires = [
    'ascent-2.7+<3',
    'caviar-0.8.2.m1+<1',
    'mythology-0.4+<2',
    'beetle-0.20+<1'
]

timestamp = 1599561978

format_version = 2
