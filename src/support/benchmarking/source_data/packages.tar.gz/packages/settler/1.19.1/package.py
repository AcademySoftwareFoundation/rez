# -*- coding: utf-8 -*-

name = 'settler'

version = '1.19.1'

requires = [
    'ascent-2.7+<3',
    'caviar-0.8.2.m1+<20',
    'mythology-0.4+<2',
    'aside-2+<6',
    'collar-1.36+<2',
    'beetle-3.21.0+<4',
    'wad-0.2+<1',
    'waffle-0.10+<1'
]

timestamp = 1599561977

format_version = 2
