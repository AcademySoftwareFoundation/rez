# -*- coding: utf-8 -*-

name = 'settler'

version = '0.32.1'

requires = [
    'ascent-2.7+<3',
    'caviar-0.8.2.m1+<19',
    'mythology-0.4+<2',
    'aside-0.1.1+<2',
    'beetle-1.7+<2',
    'collar-0.26+<1'
]

timestamp = 1599561979

format_version = 2
