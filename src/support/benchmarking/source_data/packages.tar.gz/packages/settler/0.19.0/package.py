# -*- coding: utf-8 -*-

name = 'settler'

version = '0.19.0'

requires = [
    'ascent-2.7+<3',
    'caviar-0.8.2.m1+<1',
    'mythology-0.4+<2',
    'aside-0.1.1+<1',
    'beetle-0.46+<1'
]

timestamp = 1599561980

format_version = 2
