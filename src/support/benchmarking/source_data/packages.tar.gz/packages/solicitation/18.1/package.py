# -*- coding: utf-8 -*-

name = 'solicitation'

version = '18.1'

variants = [
    ['strand-linux', 'candelabra-x86_64', 'ascent-2.7'],
    ['strand-linux', 'candelabra-x86_64', 'ascent-3.6']
]

timestamp = 1599561509

format_version = 2
