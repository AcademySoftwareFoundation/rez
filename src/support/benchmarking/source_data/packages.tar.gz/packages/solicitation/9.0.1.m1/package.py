# -*- coding: utf-8 -*-

name = 'solicitation'

version = '9.0.1.m1'

variants = [['strand-linux', 'candelabra-x86_64', 'ascent-2.7']]

timestamp = 1599561509

format_version = 2
