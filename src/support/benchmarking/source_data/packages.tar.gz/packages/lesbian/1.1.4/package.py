# -*- coding: utf-8 -*-

name = 'lesbian'

version = '1.1.4'

requires = ['ascent']

timestamp = 1599561472

format_version = 2
