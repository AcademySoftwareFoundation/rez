# -*- coding: utf-8 -*-

name = 'lesbian'

version = '1.2.0.beta.6'

requires = ['ascent']

timestamp = 1599561472

format_version = 2
