# -*- coding: utf-8 -*-

name = 'lesbian'

version = '1.3.0.beta.0'

requires = ['ascent']

timestamp = 1599561472

format_version = 2
