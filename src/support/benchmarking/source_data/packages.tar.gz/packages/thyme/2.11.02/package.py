# -*- coding: utf-8 -*-

name = 'thyme'

version = '2.11.02'

variants = [['strand-linux', 'candelabra-x86_64']]

timestamp = 1599561455

format_version = 2
