# -*- coding: utf-8 -*-

name = 'wetsuit'

version = '0.1.0'

timestamp = 1599561784

format_version = 2
