# -*- coding: utf-8 -*-

name = 'buckwheat'

version = '3.6.7.m2'

requires = ['processing-2015+<2020']

timestamp = 1599561476

format_version = 2
