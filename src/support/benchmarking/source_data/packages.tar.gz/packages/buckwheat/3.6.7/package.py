# -*- coding: utf-8 -*-

name = 'buckwheat'

version = '3.6.7'

requires = ['processing-2015+<2018']

timestamp = 1599561476

format_version = 2
