# -*- coding: utf-8 -*-

name = 'buckwheat'

version = '3.6.7.m1'

requires = ['processing-2015+<2019']

timestamp = 1599561476

format_version = 2
