# -*- coding: utf-8 -*-

name = 'shop'

version = '5.3.0'

requires = [
    'hugger-0',
    'haircut-3.7+<4',
    'lens-0',
    'minion-0.1+<1',
    'mythology-0.4.1.m2+<2',
    'ascent-2'
]

timestamp = 1599561599

format_version = 2
