# -*- coding: utf-8 -*-

name = 'shop'

version = '6.1.1'

requires = [
    'hugger-0',
    'haircut-4.0.2+<5',
    'waffle-0.37.1+<1',
    'lens-0',
    'mythology-0.4.1.m2+<2',
    'ascent-2',
    '~founding-6.1+<7'
]

timestamp = 1599561599

format_version = 2
