# -*- coding: utf-8 -*-

name = 'cartload'

version = '1.31.0'

requires = [
    'astrakhan-16',
    'runway-3',
    'publishing-1.88+<2',
    'barber-0.8.1+<0.9',
    'charm-5.1+<6',
    'waffle-0.9+<1',
    'ascent-2.7+<3',
    'escalator-0.0+<0.2.0'
]

timestamp = 1599561934

format_version = 2
