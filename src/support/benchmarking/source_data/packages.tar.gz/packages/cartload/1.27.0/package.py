# -*- coding: utf-8 -*-

name = 'cartload'

version = '1.27.0'

requires = [
    'ascent-2.7+<3',
    'publishing-1.88+<2',
    'entrance-2.6+<3',
    'waffle-0.9+<1',
    'barber-0.8.1+<0.9',
    'runway-3',
    'astrakhan-16',
    'typeface-4'
]

timestamp = 1599561933

format_version = 2
