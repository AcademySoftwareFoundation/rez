# -*- coding: utf-8 -*-

name = 'cartload'

version = '2.4.1'

requires = [
    'runway-3',
    'escalator-0.8+<1',
    'publishing-1.88+<2',
    'barber-0.9+<1',
    'waffle-0.9+<1',
    'ascent-2.7+<3',
    'dromedary-0.2+<1'
]

timestamp = 1599561934

format_version = 2
