# -*- coding: utf-8 -*-

name = 'cartload'

version = '2.16.0'

requires = [
    'escalator-0.9.0+<1',
    'publishing-1.92.0+<2',
    'barber-0.10.0+<1',
    'waffle-0.41+<1',
    'ascent-2.7+<3',
    'dromedary-0.11+<1'
]

timestamp = 1599561935

format_version = 2
