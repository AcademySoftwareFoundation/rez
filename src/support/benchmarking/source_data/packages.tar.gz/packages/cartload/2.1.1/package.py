# -*- coding: utf-8 -*-

name = 'cartload'

version = '2.1.1'

requires = [
    'runway-3',
    'escalator-0.0+<0.2.0',
    'publishing-1.88+<2',
    'barber-0.8.1+<0.9',
    'waffle-0.9+<1',
    'ascent-2.7+<3',
    'dromedary-0.2+<1'
]

timestamp = 1599561934

format_version = 2
