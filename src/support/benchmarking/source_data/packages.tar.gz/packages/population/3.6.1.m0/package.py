# -*- coding: utf-8 -*-

name = 'population'

version = '3.6.1.m0'

variants = [
    ['ascent-2.7'],
    ['ascent-3.6']
]

timestamp = 1599561562

format_version = 2
