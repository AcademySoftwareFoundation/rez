# -*- coding: utf-8 -*-

name = 'phase'

version = '9.27.0.m0'

variants = [
    ['strand-linux', 'candelabra-x86_64', 'dawn-Ubuntu-12.04', '~surrounds-4.6.3'],
    ['strand-linux', 'candelabra-x86_64', 'dawn-Ubuntu-12.04', '~surrounds-4.8.3'],
    ['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7']
]

timestamp = 1599561569

format_version = 2
