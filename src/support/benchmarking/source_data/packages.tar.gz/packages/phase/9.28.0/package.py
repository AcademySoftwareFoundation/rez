# -*- coding: utf-8 -*-

name = 'phase'

version = '9.28.0'

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7']]

timestamp = 1599561569

format_version = 2
