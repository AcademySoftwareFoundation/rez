# -*- coding: utf-8 -*-

name = 'technician'

version = '4.3.3'

requires = [
    'tugboat-0+<5',
    'grape-0+<1',
    'anarchist-1.12.0.m1+<2'
]

variants = [
    ['ascent-2.7', 'cynic-1.1.6'],
    ['ascent-3.6'],
    ['ascent-3.7'],
    ['ascent-3.8']
]

timestamp = 1599561570

format_version = 2
