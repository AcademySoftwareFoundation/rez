# -*- coding: utf-8 -*-

name = 'technician'

version = '4.3.2.m0'

requires = [
    'grape-0.2.0+<1',
    'tugboat-4.0.11+<5',
    'anarchist-1.10.0+<2'
]

variants = [
    ['ascent-2.7', 'cynic-1.1.6'],
    ['ascent-3.6']
]

timestamp = 1599561570

format_version = 2
