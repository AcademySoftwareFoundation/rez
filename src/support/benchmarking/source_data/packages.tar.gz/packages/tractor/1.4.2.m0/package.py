# -*- coding: utf-8 -*-

name = 'tractor'

version = '1.4.2.m0'

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7']]

timestamp = 1599561541

format_version = 2
