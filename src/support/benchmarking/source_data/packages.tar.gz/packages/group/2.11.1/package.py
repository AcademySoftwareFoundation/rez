# -*- coding: utf-8 -*-

name = 'group'

version = '2.11.1'

variants = [['strand-linux', 'candelabra-x86_64', 'dawn-CentOS-7']]

timestamp = 1599561642

format_version = 2
