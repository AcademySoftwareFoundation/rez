# -*- coding: utf-8 -*-

name = 'content'

version = '0.4.0'

requires = [
    'effective-1.61.0',
    'creek-2',
    'ascent-2.7'
]

variants = [
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.0',
     'caviar-18.09'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.0',
     'caviar-18.11'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.0',
     'caviar-19.05'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.1',
     'caviar-18.09'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.1',
     'caviar-18.11'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.1',
     'caviar-19.05'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.2',
     'caviar-18.09'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.2',
     'caviar-18.11'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.2',
     'caviar-19.05'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.3',
     'caviar-18.09'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.3',
     'caviar-18.11'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.3',
     'caviar-19.05']
]

timestamp = 1599561989

format_version = 2
