# -*- coding: utf-8 -*-

name = 'content'

version = '0.1.0'

requires = [
    'effective',
    'creek',
    'bird-11',
    'caviar-18'
]

variants = [
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.2',
     'caviar-18.09'],
    ['strand-linux',
     'candelabra-x86_64',
     'dawn-CentOS-7',
     'bird-11.2',
     'caviar-18.11']
]

timestamp = 1599561988

format_version = 2
